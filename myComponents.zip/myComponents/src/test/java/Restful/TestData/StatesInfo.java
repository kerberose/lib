package Restful.TestData;

/**
 * Created by holiao on 10/12/2016.
 */
public enum StatesInfo {

    URL_ALL_STATES("http://services.groupkt.com/state/get/USA/all"),
    Response_JSON_ROOT("RestResponse.result");

    private String value;
    StatesInfo(String item){
        this.value = item;
    }

    public String data(){
        return value;
    }


}
