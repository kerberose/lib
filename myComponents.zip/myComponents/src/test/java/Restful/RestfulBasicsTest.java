package Restful;
/**
 * Created by holiao on 10/11/2016.
 *
 */

/**
 * Free Restful web service to get location geolocation by IP address
 *
 * Search IP address
 * Open geo.groupkt.com/ip/<ip address>.htm  e.g. http://geo.groupkt.com/ip/172.217.3.14.htm
 *
 * JSON Rest web service to get location by IP
 * http://geo.groupkt.com/<ip address>/json  for example http://geo.groupkt.com/ip/172.217.3.14/json
 */

import static io.restassured.RestAssured.get;

import Restful.TestData.StatesInfo;
import io.restassured.http.Header;
import io.restassured.response.Response;

import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

public class RestfulBasicsTest{

//    static final List<String> Expected_HEADERS = "'a','b','c'";

    RestfulBasics rb = new RestfulBasics();
    Response body = rb.getResponse(StatesInfo.URL_ALL_STATES.data());

    @Test
    public void TestGetAllData(){
        System.out.print(body.asString());
    }

    @Test
    public void Test_VerifyHeaders(){
        for (Header header : body.getHeaders()) {
            System.out.println(header.getName());
        }
    }

    @Test
    public void Test_VerifyStatus(){
        Assert.assertEquals(body.getStatusCode(), 200);
    }

    @Test
    public void Test_SearchByCondition1_Total(){

        String criteria ="findAll {result -> result.name < 'B'}";
        List<Map> result = rb.searchByCondition(body, StatesInfo.Response_JSON_ROOT.data(), criteria);

        //TC_1: Verified the total number.
        System.out.print("TC_1: Verify the total number./n");
        Assert.assertEquals(result.size(), 5);

        //TC_2: Verify the responsed items are correct as expected.
        for(Map item:result){
            System.out.println(item.get("name"));
        }

        boolean bn = result.contains("'name' -> 'Alabama'");
        Assert.assertEquals(bn, true);
    }


}
