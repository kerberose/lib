package Restful;


/**
 * RA API
 * http://www.javadoc.io/doc/io.rest-assured/rest-assured/3.0.1
 */
import io.restassured.RestAssured;
import io.restassured.http.Cookie;
import io.restassured.http.Headers;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import static io.restassured.RestAssured.get;

import java.util.List;
import java.util.Map;


/**
 * Created by holiao on 10/11/2016.
 */
public class RestfulBasics {

    public Response getResponse(String url){
        RestAssured.baseURI= url;
        Response response = get();
        return response;
    }

    public Headers getHeaders(Response response) {
        Headers allHeaders = response.getHeaders();
        return allHeaders;
    }

    public String getCookie(Response response, String cookieName) {
        String ck = response.getCookie(cookieName);
        return ck;
    }

    public void getStatus(Response response){
        int code = response.getStatusCode();
        if(code != 200) {

        }
    }

    public List<Map> searchByCondition(Response response, String root, String searchCriteria){
        JsonPath jp = new JsonPath(response.asString()).setRoot(root);
        List<Map> results = jp.get(searchCriteria);
        return results;
    }

}
