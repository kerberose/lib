FEDSInputGenerator ReadMe
This is a small program to create a data file to be read by jmeter.  In order to run the program one must supply an input file path, output file path, option to include duplicates, and
 FEDS criteria names/indexes as arguments.  Example args: C:\Dev\UHG\uhg.csv C:\Dev\uhg\uhg_jmeter_input.csv "Y" "Drawer" "Key1 Member Id" "Key2 Group Number" "Key5 Seqnbr".  
 The FEDSInputGenerator reads the input file (uhg.csv) that contains a <DocumentSearchRequest/> xml secion on each line.  The program locates the values for the specified
 indexes (Drawer, Key1 Member Id, etc) and writes them to the specified output file.  The output can then be used as input for a jmeter test.  The third parameter (either Y or N) specifies whether
 or not to include duplicate request parameters in the output.
 
 example run command:
 C:\Dev\webdev2\web-services\scalability_testing\FEDS>java -jar FEDSInputGenerator.jar C:\Dev\UHG\uhg_input.csv C:\Dev\uhg\uhg_data.csv "N" "Drawer" "Key1 Member Id" "Key2 Group Number" "Key5 Seqnbr"
 